//A. Kubaszek, 2018-06, lic. MIT
//Skryptozakładka dla edytora HTML w Joomla z dodatkiem SIGPLUS
//zamienia łącze wstawionego obrazka `<img src="images...` na łącze galerii `sigplus`: `{gallery ... /gallery}`.
//Na moment zamiany przełącza edytor z widoku HTML WYSIWYG na źródło HTML
  var textarea1 = document.querySelector('textarea#jform_articletext')
  if (!(textarea1)) {
    alert('1. Coś jest nie tak \n - musisz być w trybie edycji html'); return;
  }
//<span role="button" class="wf_editor_toggle" aria-labelledby="wf_editor_jform_articletext_toggle" style="cursor: pointer;">
//  <span id="wf_editor_jform_articletext_toggle">[Toggle Editor]</span></span>
  document.querySelector('span#wf_editor_jform_articletext_toggle').parentNode.click();
  console.log(textarea1);
  var s = textarea1.value;
//console.log('s='+s);
//s='<p><img src="images/galerie/2018-06-11_abc/201806.JPG" alt="201806" /></p> aabbcc /> ddddddd'
  var s2=s.replace(/<img src="images\/(.*?)\/[^/]+\/>/,
    '{gallery maxcount=1 alignment="after-float" preview_width=120 preview_height=160}$1{/gallery}');
//console.log('s2='+s2);
//s2='<p>{gallery maxcount=1 alignment="after-float" preview_width=120 preview_height=160}galerie/2018-06-11_abc{/gallery}</p> aabbcc /> ddddddd'
  if (s2===s) {
    alert('2. Coś jest nie tak \n - może nie ma wstawionego obrazka...\n - a może edytor nie jest trybie HTML'); return;
  }
  textarea1.value = s2;
  document.querySelector('span#wf_editor_jform_articletext_toggle').parentNode.click();

//(zob. http://bookmarklets.org - maker [x][x][x][_]):
//javascript:void%20function(){var%20e=document.querySelector(%22textarea%23jform_articletext%22);if(!e)return%20void%20alert(%221.%20Coś%20jest%20nie%20tak%20\n%20-%20musisz%20być%20w%20trybie%20edycji%20html%22);document.querySelector(%22span%23wf_editor_jform_articletext_toggle%22).parentNode.click(),console.log(e);var%20t=e.value,r=t.replace(/%3Cimg%20src=%22images\/(.*%3F)\/[^/]+\/%3E/,'{gallery%20maxcount=1%20alignment=%22after-float%22%20preview_width=120%20preview_height=160}$1{/gallery}');return%20r===t%3Fvoid%20alert(%222.%20Coś%20jest%20nie%20tak%20\n%20-%20może%20nie%20ma%20wstawionego%20obrazka...\n%20-%20a%20może%20edytor%20nie%20jest%20trybie%20HTML%22):(e.value=r,void%20document.querySelector(%22span%23wf_editor_jform_articletext_toggle%22).parentNode.click())}();